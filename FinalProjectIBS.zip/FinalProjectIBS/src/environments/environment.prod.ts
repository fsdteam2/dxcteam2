export const environment = {
  production: true,
  appTitle: "Integrated Banking System",
  logo:"assets/image/ibs logo.jfif",
  bankEndPoint:"",
  loginEndPoint:"",
  regEndPoint:""
};
