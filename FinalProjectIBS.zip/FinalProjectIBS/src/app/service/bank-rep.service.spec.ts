import { TestBed } from '@angular/core/testing';

import { BankRepService } from './bank-rep.service';

describe('BankRepService', () => {
  let service: BankRepService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(BankRepService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
