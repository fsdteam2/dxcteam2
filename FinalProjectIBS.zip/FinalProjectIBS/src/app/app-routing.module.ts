import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomepageComponent } from './component/homepage/homepage.component';
import { LoginComponent } from './component/login/login.component';
import { RegistrationComponent } from './component/registration/registration.component';
import { CustomerAccountComponent } from './component/customer-account/customer-account.component';
import { SignUpComponent } from './component/sign-up/sign-up.component';
import { BankRepComponent } from './component/bank-rep/bank-rep.component';


const routes: Routes = [
  { path: '', pathMatch: 'full', redirectTo: '/home' },
  { path: 'home', component: HomepageComponent },
  { path: 'login', component: LoginComponent},
  { path: 'signup', component: RegistrationComponent },
  {path:'registration',component:SignUpComponent},
  {path:'customer',component:CustomerAccountComponent},
  {path:'bankRep',component:BankRepComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
