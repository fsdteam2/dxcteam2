export class RDAccount {
    public rdInterest:number;
}
