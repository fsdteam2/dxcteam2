import { SavingsAccount } from './savings-account';

describe('SavingsAccount', () => {
  it('should create an instance', () => {
    expect(new SavingsAccount()).toBeTruthy();
  });
});
