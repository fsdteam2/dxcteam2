export class CustomerDetails {
    
    public custId:number;
    public name:string;
    public addharNo:number;
    public phnNo:number;
    public account:Account;
    public userId:number;  
    public pwd: string; 
    public minStat:string;
}
