export class FDAccount {

    public fdInterest:number;

}
