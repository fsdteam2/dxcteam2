export class Transaction {

    public transId:number;
    public accType:string;
    public transType:string;
    
}
