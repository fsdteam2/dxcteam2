import { UserLogin } from './user-login';

describe('UserLogin', () => {
  it('should create an instance', () => {
    expect(new UserLogin()).toBeTruthy();
  });
});
