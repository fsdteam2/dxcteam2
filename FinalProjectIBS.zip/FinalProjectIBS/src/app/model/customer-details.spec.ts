import { CustomerDetails } from './customer-details';

describe('CustomerDetails', () => {
  it('should create an instance', () => {
    expect(new CustomerDetails()).toBeTruthy();
  });
});
