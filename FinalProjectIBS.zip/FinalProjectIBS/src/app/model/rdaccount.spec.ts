import { RDAccount } from './rdaccount';

describe('RDAccount', () => {
  it('should create an instance', () => {
    expect(new RDAccount()).toBeTruthy();
  });
});
