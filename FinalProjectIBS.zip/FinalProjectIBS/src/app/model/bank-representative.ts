export class BankRepresentative {
    public empName:string;
    public empId:number;
}
