export class SavingsAccount {
    public periodicInterest:number;
}
