import { BankRepresentative } from './bank-representative';

describe('BankRepresentative', () => {
  it('should create an instance', () => {
    expect(new BankRepresentative()).toBeTruthy();
  });
});
