import { FDAccount } from './fdaccount';

describe('FDAccount', () => {
  it('should create an instance', () => {
    expect(new FDAccount()).toBeTruthy();
  });
});
