export class UserLogin {
    public custId: number;
    public password: string;
}
