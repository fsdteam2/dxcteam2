import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { faExclamationCircle } from '@fortawesome/free-solid-svg-icons';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-sign-up',
  templateUrl: './sign-up.component.html',
  styleUrls: ['./sign-up.component.css']
})
export class SignUpComponent implements OnInit {

  signUpForm: FormGroup;
  errIcon=faExclamationCircle;

  constructor(
    private activatedRoute: ActivatedRoute,
    private router:Router,
    private fb:FormBuilder
  ) {
    this.signUpForm = fb.group({
      
      adhaarNumber:['',Validators.required],
      password:['',[Validators.required,Validators.minLength(5),Validators.maxLength(10)]],
      cPassword:['',[Validators.required]]
    });
   }

   get f(){
     return this.signUpForm.controls;
   }
  ngOnInit(): void {
  }

  signUp(){
   this.router.navigateByUrl("/customer");
  }
}
