import { Component, OnInit } from '@angular/core';
import { environment } from 'src/environments/environment';
import { faHome,  faSignInAlt } from '@fortawesome/free-solid-svg-icons';
import { Router } from '@angular/router';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  logo:any;
  brandName:string;
  links:any[];
  constructor(private router:Router) {
    this.logo = environment.logo;
    this.brandName= environment.appTitle;
    this.links = [
      {icon:faHome,path:'/home',linkText:'Home'},
      {icon:faSignInAlt,path:'/signup',linkText:'SignIn'},
      //{icon:faPowerOff,path:'/login',linkText:'LogIn'}
      {path:'/bankRep',linkText:'BankRepresentative Login'}
    
    ]
   }

  ngOnInit(): void {
  }

}
