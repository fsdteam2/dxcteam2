import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { SignUpService } from 'src/app/service/sign-up.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AuthService } from 'src/app/service/auth.service';
import { Signup } from 'src/app/model/signup';
import { faExclamationCircle } from '@fortawesome/free-solid-svg-icons';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  loginForm: FormGroup;
  errMsg:string;
  errIcon = faExclamationCircle;

  constructor(private fb: FormBuilder,
    private authService: AuthService,
    private router: Router
    ) {
    this.loginForm = fb.group({
      custId: ['', Validators.required],
      password: ['', Validators.required]
    });
  }

  get f() {
    return this.loginForm.controls;
  }

  ngOnInit(): void {
  }

  login() {
  //   let customer:Signup= this.loginForm.value;
  //   this.authService.login(customer).subscribe(
  //     (data) => {this.router.navigateByUrl("/home")},
  //     (err) => {
  //       this.errMsg="Login Denied!";
  //       console.log(JSON.stringify(err));
  //     }
  //   )
  }

}
