import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { faExclamationCircle } from '@fortawesome/free-solid-svg-icons';
import { ActivatedRoute, Router } from '@angular/router';
import { SignUpService } from 'src/app/service/sign-up.service';

@Component({
  selector: 'app-bank-rep',
  templateUrl: './bank-rep.component.html',
  styleUrls: ['./bank-rep.component.css']
})
export class BankRepComponent implements OnInit {

  errMsg: string;
  bankRepForm: FormGroup;
  errIcon = faExclamationCircle;

  constructor(
    private activatedRoute: ActivatedRoute,
    private userService: SignUpService,
    private router: Router,
    private formBuilder: FormBuilder) {
    this.bankRepForm = formBuilder.group({

      empId: ['',Validators.required],
      empName: ['',Validators.required]
     
    });
    
    
    }
    get f(){
      return this.bankRepForm.controls;
    }

  ngOnInit(): void {
  }
  save(){
    let obr = this.userService.add(this.bankRepForm.value);
    
    obr.subscribe(
      (data) => {this.router.navigateByUrl("/bankRep");},
      (err)=>{console.log(err.message);}
    );

  }
  

}
