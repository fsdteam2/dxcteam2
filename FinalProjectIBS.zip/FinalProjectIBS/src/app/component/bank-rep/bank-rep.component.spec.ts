import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BankRepComponent } from './bank-rep.component';

describe('BankRepComponent', () => {
  let component: BankRepComponent;
  let fixture: ComponentFixture<BankRepComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BankRepComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BankRepComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
