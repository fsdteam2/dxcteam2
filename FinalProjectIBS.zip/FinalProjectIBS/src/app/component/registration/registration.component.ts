import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { SignUpService } from 'src/app/service/sign-up.service';
import { faExclamationCircle } from '@fortawesome/free-solid-svg-icons';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {

  errMsg: string;
  regForm: FormGroup;
  accounts:string[];
  errIcon = faExclamationCircle;
  

  constructor(
    private activatedRoute: ActivatedRoute,
    private userService: SignUpService,
    private router: Router,
    private formBuilder: FormBuilder) {
    this.regForm = formBuilder.group({

      custId: ['',Validators.required],
      name: ['',Validators.required],
      addharNumber: ['',Validators.required],
      phnNo: ['',Validators.required],
      account:['',Validators.required]
      
     

    });
    this.accounts = ["Saving Account","FD Account","RD account"]

  }

  get f(){
    return this.regForm.controls;

  }
  ngOnInit(): void {
    
  }

  save(){
    let obr = this.userService.add(this.regForm.value);
    
    obr.subscribe(
      (data) => {this.router.navigateByUrl("/registration");},
      (err)=>{console.log(err.message);}
    );

  }

}
